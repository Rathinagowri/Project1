function showhide()
 {
       var div1 = document.getElementById("n1");
       var div2 = document.getElementById("n2");
       var div3 = document.getElementById("n3");
       var div4 = document.getElementById("n4");
       var div5= document.getElementById("n5");
      if (div1.style.display !== "none") {
    div1.style.display = "none";
}
else {
    div1.style.display = "block";
    div2.style.display = "none";
    div3.style.display = "none";
    div4.style.display = "none";
    div5.style.display = "none";
} 
}
    
 function showhide1()
 {
 	   var div1 = document.getElementById("n1");
       var div2 = document.getElementById("n2");
       var div3 = document.getElementById("n3");
       var div4 = document.getElementById("n4");
       var div5= document.getElementById("n5");
      if (div2.style.display !== "none") {
    div2.style.display = "none";
}
else {
    div2.style.display = "block";
    div1.style.display = "none";
    div3.style.display = "none";
    div4.style.display = "none";
    div5.style.display = "none";
}  
}    


function showhide2()
 {
 	   var div1 = document.getElementById("n1");
       var div2 = document.getElementById("n2");
       var div3 = document.getElementById("n3");
       var div4 = document.getElementById("n4");
       var div5 = document.getElementById("n5");
      if (div3.style.display !== "none") {
    div3.style.display = "none";
}
else {
    div3.style.display = "block";
    div1.style.display = "none";
    div2.style.display = "none";
    div4.style.display = "none";
    div5.style.display = "none";
}       
}

function showhide3()
 {
 	   var div1 = document.getElementById("n1");
       var div2 = document.getElementById("n2");
       var div3 = document.getElementById("n3");
       var div4 = document.getElementById("n4");
       var div5= document.getElementById("n5");
      if (div4.style.display !== "none") {
    div4.style.display = "none";
}
else {
    div4.style.display = "block";
    div1.style.display = "none";
    div3.style.display = "none";
    div2.style.display = "none";
    div5.style.display = "none";
}  
}

  function showhide4()
 {
 	   var div1 = document.getElementById("n1");
       var div2 = document.getElementById("n2");
       var div3 = document.getElementById("n3");
       var div4 = document.getElementById("n4");
       var div5= document.getElementById("n5");
      if (div5.style.display !== "none") {
    div5.style.display = "none";
}
else {
    div5.style.display = "block";
    div1.style.display = "none";
    div3.style.display = "none";
    div4.style.display = "none";
    div2.style.display = "none";
}  
          
     
}



 